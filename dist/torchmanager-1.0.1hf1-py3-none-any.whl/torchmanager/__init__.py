import logging

from . import losses, metrics, train
from .managers import Manager, VerboseType

version = "1.0.1"
