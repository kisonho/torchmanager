from .cross_entropy import CrossEntropy, FocalCrossEntropy, KLDiv
from .losses import Loss, MultiLosses, MultiOutputsLosses, loss