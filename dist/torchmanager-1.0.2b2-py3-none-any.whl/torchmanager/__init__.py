from . import losses, metrics, train
from .core.view import VerboseType, logging
from .managers import Manager

version = "1.0.2b1"
