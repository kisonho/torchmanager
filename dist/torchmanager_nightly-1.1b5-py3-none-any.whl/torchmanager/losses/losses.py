from torchmanager_core.view import warnings

from .loss import *

warnings.warn("This module has been deprecated after v1.1.0 and will be removed in v1.2.0, use `loss` instead.", PendingDeprecationWarning)