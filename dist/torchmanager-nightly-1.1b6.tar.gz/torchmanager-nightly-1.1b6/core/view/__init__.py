import logging, warnings
from tqdm import tqdm

from .protocols import VerboseType

logger = logging.getLogger('torchmanager')