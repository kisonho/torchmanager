from importlib_metadata import version
from . import callbacks, losses, metrics, train
from .managers import *
version = "1.0.0rc4"