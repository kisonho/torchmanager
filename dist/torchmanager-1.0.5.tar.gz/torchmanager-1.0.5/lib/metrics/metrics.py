from torchmanager_core.view import warnings

from .metric import *

warnings.warn("This module will be deprecated after v1.1.0 and will be removed in v1.2.0, use `metric` instead.", PendingDeprecationWarning)